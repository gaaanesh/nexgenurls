<title>Page not Found</title>
<style type="text/css">
	body{
		display: flex;
	    justify-content: center;
	    align-items: center;
	    font-family: calibri;
	}
	h1{
		font-size: 220px;
    	margin: 0;
	}
	p{
		font-size: 50px;
	    font-weight: 600;
	    margin: 0;
	    margin-bottom: 35px;
	}
	button{
		background: #1e3f9a;
	    border-color: #1e3f9a;
	    padding: 7px 20px;
	    font-size: 20px;
	    font-weight: 500;
	    color: #fff;
	    outline: none !important;
	    border: 2px solid;
	    letter-spacing: 0.5px;
	    border-radius: 4px;
	    box-shadow: 0 1px 3px rgba(0,0,0,0.09);
	}
	a{
		color: #fff;
		text-decoration: none;
	}
</style>

<div style="text-align: center;">
	<h1>404</h1>
	<p>Page Not Found</p>
	<button type="button"><a href="/">Back to Home</a></button>
</div>